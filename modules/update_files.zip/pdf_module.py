import re
import os
import pandas as pd
from PyPDF2 import PdfReader
from concurrent.futures import ThreadPoolExecutor, as_completed
from PyQt6.QtWidgets import *
from PyQt6.QtCore import *

PATTERNS = {
    "pattern0": re.compile(r"税款所属期间.+?(\d{4}-\d{2}-\d{2}\D*\d{4}-\d{2}-\d{2})|自.?(\d{4}年.?\d{1,2}月.?\d{1,2}日).?至.?(\d{4}年.?\d{1,2}月.?\d{1,2}日).?"),
    "pattern1": re.compile(r"按适用税率计税销售额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern2": re.compile(r"按简易办法计税销售额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern3": re.compile(r"免、抵、退办法出口销售额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern4": re.compile(r"免税销售额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern5": re.compile(r"销项税额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern6": re.compile(r'\b进项税额\b\s+\d+\s+(\d+(?:,\d+)*\.\d+)\s*'),
    "pattern7": re.compile(r"进项税额转出\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern8": re.compile(r"期末留抵税额\s+\d+[=＝]\d+[-\－]\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern9": re.compile(r"简易计税办法计算的应纳税额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern10": re.compile(r"应纳税额合计\s+\d+=\d+\+\d+-\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern11": re.compile(r"应纳税额减征额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern12": re.compile(r"城市维护建设税本期应补（退）税额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern13": re.compile(r"教育费附加本期应补（退）费额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern14": re.compile(r"地方教育附加本期应补（退）费额\s+\d+\s+(\d{1,3}(?:,\d{3})*\.\d{2}|\d+\.\d{2})"),
    "pattern15": re.compile(r'纳税人名称[：:]?\s*([\u4e00-\u9fa5]{2,40}?(?:公司|集团)(?:有限)?公司[\u4e00-\u9fa5]{0,15}?(?:分公司)?)'),
}

def clean_company_name(name):
    if not name: return name
    stop_words = ['法定代表人姓', '注册地址', '金额单位', '纳税人识别号']
    for word in stop_words:
        if word in name: name = name.split(word)[0].strip()
    return re.sub(r'\s+', ' ', name).strip()

def process_single_pdf(file_path):
    try:
        reader = PdfReader(file_path)
        if len(reader.pages) < 1: return None
        page1_text = reader.pages[0].extract_text()
        page2_text = reader.pages[1].extract_text() if len(reader.pages) > 1 else ""
        c1, c2 = re.sub(r'\s+', ' ', page1_text), re.sub(r'\s+', ' ', page2_text)
        company_match = PATTERNS["pattern15"].search(c2) or PATTERNS["pattern15"].search(c1)
        company_name = clean_company_name(company_match.group(1).strip()) if company_match else "未知公司"
        res = {"文件名": os.path.basename(file_path), "所在文件夹": os.path.basename(os.path.dirname(file_path)), "公司名称": company_name}
        for k in PATTERNS:
            if k == "pattern15": continue
            match = PATTERNS[k].search(c1)
            res[k] = match.group(1) if match else None
        return res
    except: return None

class PDFWorker(QThread):
    log_sig = pyqtSignal(str)
    prog_sig = pyqtSignal(int)
    finish_sig = pyqtSignal(bool, str, str)

    def __init__(self, folder):
        super().__init__()
        self.folder = folder

    def run(self):
        try:
            pdf_files = []
            for root, _, files in os.walk(self.folder):
                for f in files:
                    if f.lower().endswith('.pdf') and "增值税" in f: pdf_files.append(os.path.join(root, f))
            if not pdf_files:
                self.finish_sig.emit(False, "未发现符合要求的PDF文件。", "")
                return
            results = []
            with ThreadPoolExecutor() as executor:
                futures = {executor.submit(process_single_pdf, f): f for f in pdf_files}
                for i, future in enumerate(as_completed(futures)):
                    res = future.result()
                    if res: results.append(res)
                    self.prog_sig.emit(int((i + 1) / len(pdf_files) * 100))
            if results:
                df = pd.DataFrame(results)
                output_path = os.path.join(self.folder, "增值税全量汇总统计表.xlsx")
                df.to_excel(output_path, index=False)
                self.finish_sig.emit(True, f"处理完成！提取了 {len(results)} 条数据。", output_path)
            else: self.finish_sig.emit(False, "未提取到任何数据。", "")
        except Exception as e: self.finish_sig.emit(False, str(e), "")

class PDFPage(QWidget):
    def __init__(self):
        super().__init__()
        self.last_output_dir = ""
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        group = QGroupBox("增值税申报表(PDF文件)主表数据提取")
        grid = QGridLayout(group)
        grid.addWidget(QLabel("文件夹目录:"), 0, 0)
        self.dir_edit = QLineEdit(); grid.addWidget(self.dir_edit, 0, 1)
        btn_dir = QPushButton("选择文件夹"); btn_dir.clicked.connect(self.select_dir); grid.addWidget(btn_dir, 0, 2)
        grid.addWidget(QLabel("处理进度:"), 1, 0)
        self.pbar = QProgressBar(); grid.addWidget(self.pbar, 1, 1)
        layout.addWidget(group)
        btn_layout = QHBoxLayout()
        self.run_btn = QPushButton("🚀 开始提取"); self.run_btn.setFixedHeight(45); self.run_btn.clicked.connect(self.start_task)
        self.open_dir_btn = QPushButton("📂 打开结果目录"); self.open_dir_btn.setFixedHeight(45); self.open_dir_btn.setEnabled(False); self.open_dir_btn.clicked.connect(self.open_result_folder)
        btn_layout.addWidget(self.run_btn); btn_layout.addWidget(self.open_dir_btn)
        layout.addLayout(btn_layout)
        self.log_area = QTextEdit(); self.log_area.setReadOnly(True); layout.addWidget(self.log_area)

    def select_dir(self):
        path = QFileDialog.getExistingDirectory(self, "选择文件夹")
        if path: self.dir_edit.setText(path)

    def start_task(self):
        if not self.dir_edit.text(): return
        self.run_btn.setEnabled(False); self.pbar.setValue(0); self.log_area.clear()
        self.worker = PDFWorker(self.dir_edit.text()); self.worker.prog_sig.connect(self.pbar.setValue); self.worker.finish_sig.connect(self.on_finish); self.worker.start()

    def on_finish(self, success, msg, output_path):
        self.run_btn.setEnabled(True)
        if success:
            self.last_output_dir = os.path.dirname(output_path)
            self.open_dir_btn.setEnabled(True)
            QMessageBox.information(self, "完成", msg)
        else: QMessageBox.critical(self, "错误", msg)

    def open_result_folder(self):
        if self.last_output_dir: os.startfile(self.last_output_dir)

def get_interface():
    return "增值税申报表主表取数", PDFPage()